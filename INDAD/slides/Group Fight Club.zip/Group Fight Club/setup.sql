# noinspection SqlNoDataSourceInspectionForFile

USE CUSTOMER;

CREATE TABLE customer (
	id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
	username VARCHAR(50) NOT NULL,
	password VARCHAR(100) NOT NULL,
	firstName VARCHAR(50),
	lastName VARCHAR(100)
);


CREATE TABLE rental (
	id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
	customerId INTEGER NOT NULL,
	movieId INTEGER NOT NULL,
	open BOOLEAN NOT NULL
);

/*
MySQL doesn't support multiple triggers with the same action.
This trigger enforces the two constraints: Only three movies can be
rented by a customer at a time, and no movie can be rented out to more
than one customer at a time.
 */

DELIMITER $$

CREATE TRIGGER constraints before insert
On rental
For each row
Begin
IF (EXISTS (
	SELECT * FROM rental
	WHERE open=true AND movieId = new.movieId
) OR (3 <= (
	SELECT count(*) FROM rental
	WHERE open=true AND customerId = new.customerId)
)) THEN signal sqlstate '45000' set message_text = 'A movie can only be rented to one customer at a time and one customer can only rent 3 movies at a time.';
END IF;
END$$
DELIMITER ;

/* Create a test-customer for the program. */
INSERT INTO customer (username, password, firstName, lastName) VALUES ('mallory', 1234, 'Mallory', 'Bobaliceson');

USE IMDB;

/* Create indices on the imdb-specific tables.
The imdb-setup.sql file must run first. */
CREATE INDEX i_personId ON involved(personId);
CREATE INDEX i_movieId ON involved(movieId);
CREATE INDEX i_pmId ON involved(personId, movieId);