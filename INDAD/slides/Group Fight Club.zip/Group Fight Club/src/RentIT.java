import command.*;
import db.API;
import db.DB;
import model.Customer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RentIT {

	private Customer sessionCustomer;
	private Map<String, ICommand> commands;
	private BufferedReader reader;
	private PrintWriter writer;
	private ICommand helpCommand;
	private ICommand statusCommand;
	private String inputCommandPattern = "([^\\s]+)\\s*([^\\n]*)";
	private API api;

	private boolean isLoggedIn() {
			return sessionCustomer != null;
	}

	public RentIT() {
			reader = new BufferedReader(new InputStreamReader(System.in));
			writer = new PrintWriter(System.out);
			commands = new HashMap<>();
			api = new API(
					new DB(DB.DB_URL_CUSTOMER),
					new DB(DB.DB_URL_IMDB)
			);
	}

	public static void main(String[] args) {
			RentIT program = new RentIT();
			program.run();
	}

	public void run() {
			printWelcomeMessage();

			try {
					waitForAuthentication();
					setup();

					helpCommand.execute(null);

					// Keep executing commands for the rest of the program lifetime.
					while (isLoggedIn()) {
							statusCommand.execute(null);

							print("\n");
							print("Please enter a command: ");
							String userInput = reader.readLine();

							CommandInput input = extractCommandInput(userInput);
							ICommand command = getCommand(input.getCommandId());
							if (command != null) {
									command.execute(input);
							} else {
									println("Your command was not recognized. Please provide a valid command.");
									helpCommand.execute(null);
							}
					}
			} catch (IOException e) {
					e.printStackTrace();
			}
	}

	/**
	 * Sets up the commands.
	 */
	private void setup() {
			commands.put("search", new SearchCommand(writer, api, sessionCustomer));
			commands.put("rent", new RentCommand(writer, api, sessionCustomer));
			commands.put("return", new ReturnCommand(writer, api, sessionCustomer));

			statusCommand = new StatusCommand(writer, sessionCustomer, api);
			commands.put("status", statusCommand);

			helpCommand = new HelpCommand(writer, commands);
			commands.put("help", helpCommand);
	}

	/**
	 * Prints a line to the writer.
	 * @param text
	 */
	private void println(String text) {
			writer.println(text);
			writer.flush();
	}

	/**
	 * Prints a text to the writer.
	 * @param text
	 */
	private void print(String text) {
			writer.print(text);
			writer.flush();
	}

	/**
	 * Continues to ask the user for authentication untill the user is authenticated.
	 * @throws IOException
	 */
	private void waitForAuthentication() throws IOException {
			while (!isLoggedIn()) {
					print("Enter your customer name: ");
					String customerName = reader.readLine();
					print("Enter your password: ");
					String password = reader.readLine();

					// Tries to log in the user
					if (authenticate(customerName, password)) {
							printBlock();
							println("You have successfully been logged in!");
					} else {
							println("Auch! Your username or password was wrong. Please try again!");
					}
			}
	}

	/**
	 * Extracts a command input from a text.
	 * @param line
	 * @return
	 */
	private CommandInput extractCommandInput(String line) {
			Pattern r = Pattern.compile(inputCommandPattern);
			Matcher m = r.matcher(line);

			String commandId = null;
			String params = null;

			if (m.find()) {
					commandId = m.group(1);
					params = m.group(2);
			}

			return new CommandInput(commandId, params);
	}

	/**
	 * Returns a commands based on the commandId
	 * @param commandId
	 * @return
	 */
	private ICommand getCommand(String commandId) {
			return commands.get(commandId);
	}

	/**
	 * Prints a welcome message to make the user feel happy.
	 */
	private void printWelcomeMessage() {
			printBlock();
			println("Welcome to RentIT - The greatest movie renting program in the world!");
			printBlock();
	}

	/**
	 * Prints a block of hashtags to get a neat UI.
	 */
	private void printBlock() {
			println("##########################");
	}

	/**
	 * Authenticates the user. Returns wether the user was logged in or not.
	 * @param username
	 * @param password
	 * @return
	 */
	private boolean authenticate(String username, String password) {
			this.sessionCustomer = api.authenticate(username, password);
			return isLoggedIn();
	}
}
