package command;

/**
* Created by andreasmehlsen on 23/11/2016.
*/
public class CommandInput {
	private String commandId;
	private String params;

	public String getParams() {
		return params;
	}

	public String getCommandId() {
		return commandId;
	}

	public CommandInput(String commandId, String params) {
		this.commandId = commandId;
		this.params = params;
	}
}
