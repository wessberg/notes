package command;

import java.io.PrintWriter;
import java.util.Map;

public class HelpCommand implements ICommand {
	private PrintWriter writer;
	private Map<String, ICommand> commands;

	public HelpCommand(PrintWriter writer, Map<String, ICommand> commands) {
		this.writer = writer;
		this.commands = commands;
	}

	@Override
	public void execute(CommandInput input) {
		printHelp();
	}

	@Override
	public String help() {
		return "- Prints the list of available actions";
	}

	private void printHelp() {
		writer.println("##########################");
		writer.println("Available commands:");
		for (String commandId : commands.keySet()) {
			ICommand command = commands.get(commandId);
			writer.println("\t" + commandId + " " + command.help());
		}
		writer.println("##########################");
		writer.flush();
	}
}
