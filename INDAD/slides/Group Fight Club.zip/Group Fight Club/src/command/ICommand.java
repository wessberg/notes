package command;

public interface ICommand {
	void execute(CommandInput input);
	String help();
}
