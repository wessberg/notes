package command;

import db.API;
import model.Customer;

import java.io.PrintWriter;

public class RentCommand implements ICommand {

	private PrintWriter writer;
	private API api;
	private Customer customer;

	public RentCommand(PrintWriter writer, API api, Customer customer) {
		this.writer = writer;
		this.api = api;
		this.customer = customer;
	}

	@Override
	public void execute(CommandInput input) {
	    int movieId = -1;
		try {
			movieId = Integer.parseInt(input.getParams());
		} catch (NumberFormatException e) {
			writer.println("Couldn't parse input. Please supply an integer.");
			writer.flush();
		}

		boolean didRent = api.rentMovie(movieId, customer.getId());
		if (didRent)	writer.println("Movie rented successfully!\n");
		else 			writer.println("Failed to rent movie\n");

		writer.flush();
	}

	@Override
	public String help() {
		return "{{ movieId }} - Rents a movie with the given movieId. Example: 'rent 12'";
	}
}
