package command;

import db.API;
import model.Customer;

import java.io.PrintWriter;

public class ReturnCommand implements ICommand {

    private PrintWriter writer;
    private API api;
    private Customer customer;
    public ReturnCommand(PrintWriter writer, API api, Customer customer) {
        this.writer = writer;
        this.api = api;
        this.customer = customer;
    }

    @Override
    public void execute(CommandInput input) {
        if(input.getParams().matches("\\d*")) {
            int movieId = Integer.parseInt(input.getParams());
            api.closeRental(customer.getId(), movieId);
            writer.println("Movie with ID "+movieId +" returned.");
            writer.flush();
        }
        else {
            writer.println("Input not recognized as a number.");
            writer.flush();
        }
    }


	@Override
	public String help() {
		return "{{ movieId }} - Returns a movie with the given movieId. Example: 'return 12'";
	}
}
