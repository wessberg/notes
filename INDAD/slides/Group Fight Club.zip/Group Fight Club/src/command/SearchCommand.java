package command;

import db.API;
import model.Actor;
import model.Customer;
import model.Director;
import model.Movie;

import java.io.PrintWriter;
import java.util.ArrayList;

public class SearchCommand implements ICommand {

	private PrintWriter writer;
	private API api;
	private Customer customer;
	public SearchCommand(PrintWriter writer, API api, Customer customer) {
		this.writer = writer;
		this.api = api;
		this.customer = customer;
	}

	@Override
	public void execute(CommandInput input) {
			String query = input.getParams();
			ArrayList<Movie> movies = api.searchMoviesByTitle(query);

			for (Movie movie : movies) {
					writer.println(String.format("Title: %s", movie.getTitle()));
					writer.println(String.format("Movie ID: %s", movie.getId()));

					// Print
					int rentedBy = api.isMovieRented(movie.getId());
					if (rentedBy != -1) {
							boolean isRentedByLoggedInUser = (rentedBy == this.customer.getId());
							writer.println(String.format(
											"Not available for rental. Rented by %s",
											(isRentedByLoggedInUser ? "you" : "another customer")
							));
					} else {
							writer.println("Available for rental");
					}

					// Print directors
					ArrayList<Director> directors = api.getDirectorsInMovie(movie.getId());
					writer.print("Director(s): ");
					for (Director director : directors) {
							writer.print(String.format("%s, ", director.getName()));
					}
					writer.print("\n");


					// Print actors
					ArrayList<Actor> actors = api.getActorsInMovie(movie.getId());
					writer.print("Actor(s): ");
					for (Actor actor : actors) {
							writer.print(String.format("%s, ", actor.getName()));
					}
					writer.print("\n\n");
			}

			writer.flush();
	}

	@Override
	public String help() {
		return "{{ query }} - Search in the entire movie database. Example: 'search Deathnote'";
	}
}
