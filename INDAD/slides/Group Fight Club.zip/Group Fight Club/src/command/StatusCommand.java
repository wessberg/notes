package command;

import db.API;
import model.Customer;

import java.io.PrintWriter;

public class StatusCommand implements ICommand {

	private PrintWriter writer;
	private Customer customer;
	private API api;

	public StatusCommand(PrintWriter writer, Customer customer, API api) {
		this.writer = writer;
		this.customer = customer;
		this.api = api;
	}

	@Override
	public void execute(CommandInput input) {
		int currentRentals = api.getRentalCountForCustomer(customer.getId());
		int remainingRentals = Customer.MAX_RENTALS - currentRentals;
		writer.println("Current status for " + customer.getName());
		writer.println("You currently rent " + currentRentals + " movies.");
		writer.println("You may rent " + remainingRentals + " additional movies");
		writer.flush();
	}

	@Override
	public String help() {
		return "- Shows the status of your current session";
	}
}
