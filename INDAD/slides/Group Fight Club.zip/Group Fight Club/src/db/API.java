package db;

import model.Actor;
import model.Customer;
import model.Director;
import model.Movie;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class API {

	private DB dbCUSTOMER;
	private DB dbIMDB;

	public API(DB dbCUSTOMER, DB dbIMDB) {
		this.dbCUSTOMER = dbCUSTOMER;
		this.dbIMDB = dbIMDB;
	}

	public Customer authenticate(String username, String password) {
		try {
			String sql = "SELECT id, firstName, lastName FROM customer WHERE username=? AND password=?";
			PreparedStatement login = dbCUSTOMER.getConn().prepareStatement(sql);
			login.setString(1, username);
			login.setString(2, password);
			ResultSet result = login.executeQuery();
			if (result.first()) {
				return new Customer(
				result.getInt("id"),
				username,
				result.getString("firstName"),
				result.getString("lastName")
				);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Gets all rentals for a given customer.
	 * @param customerId The customerID for the customer.
	 * @returns          A list of all rental objects for the customer.
	 */
	public int getRentalCountForCustomer(int customerId) {
		try {
			String sql = "SELECT COUNT(*) as count FROM rental WHERE customerId=? AND open=true";
			PreparedStatement searchRentals = dbCUSTOMER.getConn().prepareStatement(sql);
			searchRentals.setInt(1, customerId);
			ResultSet result = searchRentals.executeQuery();

			if (result.first()) {
				return result.getInt("count");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	/**
	 * Queries the database for movies by the given title and returns a list of
	 * all matching Movie objects.
	 * @param query The movie title or parts of it.
	 * @returns     A list of all the movies that contains the query.
	 */
	public ArrayList<Movie> searchMoviesByTitle(String query) {
		ArrayList<Movie> movies = new ArrayList<>();
		try {
			String sql = "SELECT id, title FROM movie WHERE LOWER(title) LIKE ?";
			PreparedStatement searchMovies = dbIMDB.getConn().prepareStatement(sql);
			searchMovies.setString(1, "%" + query.toLowerCase() + "%");
			ResultSet result = searchMovies.executeQuery();

			while (result.next()) {
				movies.add(new Movie(
				result.getInt("id"),
				result.getString("title")
				));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return movies;
	}

	public boolean rentMovie (int movieId, int customerId) {
		try {
			String sql = "INSERT INTO rental (customerId, movieId, open) VALUES (?, ?, ?)";
			PreparedStatement addMovie = dbCUSTOMER.getConn().prepareStatement(sql);
			addMovie.setInt(1, customerId);
			addMovie.setInt(2, movieId);
			addMovie.setBoolean(3, true);
			return addMovie.executeUpdate() >= 1;
		} catch (Exception ex) {

			// The INSERT operation will fail if the movie is already rented out or the user cannot rent any
			// additional movies.
			System.out.println(ex.getMessage());
			return false;
		}
	}

	public ArrayList<Actor> getActorsInMovie(int movieId) {
		ArrayList<Actor> actors = new ArrayList<>();
		try {
			String sql = "SELECT personId, name FROM involved INNER JOIN person ON involved.personId = person.id WHERE movieId = ? AND role = 'actor'";
			PreparedStatement searchActors = dbIMDB.getConn().prepareStatement(sql);
			searchActors.setInt(1, movieId);
			ResultSet result = searchActors.executeQuery();

			while (result.next()) {
				actors.add(new Actor(
				result.getInt("personId"),
				result.getString("name")
				));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		return actors;
	}

	public ArrayList<Director> getDirectorsInMovie(int movieId) {
		ArrayList<Director> directors = new ArrayList<>();
		try {
			String sql = "SELECT personId, name FROM involved INNER JOIN person ON involved.personId = person.id WHERE movieId = ? AND role = 'director'";
			PreparedStatement searchDirectors = dbIMDB.getConn().prepareStatement(sql);
			searchDirectors.setInt(1, movieId);
			ResultSet result = searchDirectors.executeQuery();

			while (result.next()) {
				directors.add(new Director(
				result.getInt("personId"),
				result.getString("name")
				));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return directors;
	}

	//Checks if movie is rented by someone else
	public int isMovieRented(int movieId) {
		try {
			String sql = "SELECT customerId FROM rental WHERE movieId = ? AND open=true";
			PreparedStatement searchRenters = dbCUSTOMER.getConn().prepareStatement(sql);
			searchRenters.setInt(1, movieId);
			ResultSet result = searchRenters.executeQuery();

			if(result.first()) {
				return result.getInt("customerId");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public void closeRental(int customerId, int movieId) {
		try {
			String sql = "UPDATE rental SET open=false WHERE customerId=? AND movieId=?";
			PreparedStatement updateStatus = dbCUSTOMER.getConn().prepareStatement(sql);
			updateStatus.setInt(1, + customerId);
			updateStatus.setInt(2, + movieId);
			updateStatus.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
