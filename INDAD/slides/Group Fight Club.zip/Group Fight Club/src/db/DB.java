package db;

import java.sql.*;

public class DB {
	static final String USER = "root";
	static final String DB_CUSTOMER = "CUSTOMER";
	static final String DB_IMDB = "IMDB";
	public static final String DB_URL_CUSTOMER = "jdbc:mysql://localhost/" + DB_CUSTOMER;
	public static final String DB_URL_IMDB = "jdbc:mysql://localhost/" + DB_IMDB;
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";

	private String dbUrl;
	private Connection conn;

	public Connection getConn() {
		return conn;
	}

	public DB(String dbUrl) {
		this.dbUrl = dbUrl;

		try {
			createConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createConnection() throws Exception {
		Class.forName(JDBC_DRIVER);
		DriverManager.registerDriver(new com.mysql.jdbc.Driver()); //Register driver
		conn = DriverManager.getConnection(dbUrl, USER, null);
	}
}
