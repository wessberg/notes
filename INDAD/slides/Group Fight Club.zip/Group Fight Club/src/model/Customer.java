package model;

public class Customer {
	public static int MAX_RENTALS = 3;
	int id;
	String username;
	String firstName;
	String lastName;

	public String getName() {
		return firstName + " " + (lastName != null ? lastName : "");
	}

	public int getId() {
		return id;
	}

	public Customer(int id, String username, String firstName, String lastName) {
		this.id = id;
		this.username = username;
		this.firstName = firstName;
		this.lastName = lastName;
	}
}
