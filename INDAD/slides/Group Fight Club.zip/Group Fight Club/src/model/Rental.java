package model;

public class Rental {
	int id;
	int movieId;
	int customerId;
	Boolean open;

	public Rental(int id, int movieId, int customerId, Boolean open) {
		this.id = id;
		this.movieId = movieId;
		this.customerId = customerId;
		this.open = open;
	}
}
